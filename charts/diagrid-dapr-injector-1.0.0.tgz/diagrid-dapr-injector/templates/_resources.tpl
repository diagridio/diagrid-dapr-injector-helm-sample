{{- define "dapr.resource" }}
{{- $namespace := .namespace }}
{{- $files := .files }}
{{- $name := .name }}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $name }}
  namespace: {{ $namespace }}
data:
{{- if $files }}
  {{- range $path, $file := $files }}
    {{- $filename := base $path }}
    {{ $filename }}: |-
{{ $file | toString | indent 6 }}
  {{- end }}
{{- end }}
{{- end }}